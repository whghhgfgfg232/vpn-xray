Поместите сюда xray.exe для Windows.

Ожидаемый путь:
third_party/xray/xray.exe
