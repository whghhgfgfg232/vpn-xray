#pragma once

#include <QObject>
#include <QString>
#include <QTimer>

class XrayStatsMonitor : public QObject {
    Q_OBJECT

public:
    explicit XrayStatsMonitor(QObject *parent = nullptr);

    void setExecutablePath(const QString &path);
    void start();
    void stop();

signals:
    void totalsChanged(const QString &downloadText, const QString &uploadText);
    void errorText(const QString &text);

private:
    void queryNow();
    static quint64 parseCounter(const QString &output, const QString &name);
    static QString formatBytes(quint64 bytes);

    QTimer timer_;
    QString executablePath_;
    QString lastError_;
};
